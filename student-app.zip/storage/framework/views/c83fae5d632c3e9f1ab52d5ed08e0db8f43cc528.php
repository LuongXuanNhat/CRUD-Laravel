<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="pull-right">
        <a class="btn btn-primary" href="<?php echo e(route('students.index')); ?>"> Back list</a>
    </div>
    <div style="display: flex; justify-content: center">
        <div class="card" style="width: 18rem;">
            <img src="<?php echo e(asset('build/assets/account.png')); ?>" class="card-img-top" style="height: 230px;object-fit: contain;object-position: top;" alt="...">
            <div class="card-body" style="text-align: center">
              <h5 class="card-title"><?php echo e($student->name); ?></h5>
              <p class="card-text"><?php echo e($student->class); ?></p>
              <?php if($student->user->is(auth()->user())): ?>
                <a class="btn btn-warning mt-1" href="<?php echo e(route('students.edit',$student)); ?>">Edit</a>
              <?php endif; ?>
            </div>
          </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\student-app\resources\views/students/show.blade.php ENDPATH**/ ?>