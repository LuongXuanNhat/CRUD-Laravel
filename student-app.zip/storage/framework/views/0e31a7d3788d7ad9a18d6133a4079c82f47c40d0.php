<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>
   <div style="margin: 20px 100px;">
    <div class="row mb-1">
        <div class="col-lg-12 " style="display: flex">
            <div>
                <h2 style="font-size: 28px;"><strong>Student List</strong></h2>
            </div>
            <div class="pull-right" style="margin-left: auto ">
                <a class="btn btn-success" href="<?php echo e(route('students.create')); ?>"> Add Student</a>
            </div>
        </div>
    </div>

    <table class="table table-bordered" >
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Class</th>
            <th>Created</th>
            <th>Updated</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->id); ?></td>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->class); ?></td>
            <td><?php echo e($student->created_at); ?></td>
            <td><?php echo e($student->updated_at); ?></td>
            <td>
                <form action="<?php echo e(route('students.destroy',$student)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('students.show',$student)); ?>">Show</a>
                    <?php if($student->user->is(auth()->user())): ?>
                        <a class="btn btn-primary" href="<?php echo e(route('students.edit',$student)); ?>">Edit</a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" :href="route('students.destroy', $student)" 
                            onclick="event.preventDefault(); this.closest('form').submit();">Delete</button>
                    <?php endif; ?>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>
    <?php echo e($students->links()); ?>

   </div>
   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

    <?php /**PATH C:\xampp\htdocs\student-app\resources\views/students/index.blade.php ENDPATH**/ ?>